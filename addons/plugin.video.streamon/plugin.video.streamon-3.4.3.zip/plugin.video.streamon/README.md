![streamon logo](https://github.com/xstreamon/plugin.video.streamon/raw/master/icon.png)


## Willkommen bei streamon für Kodi!

Bei streamon handelt es sich um ein Video-Addon für Kodi, welches das streamen von Filmen und Serien über eine intuitive und optisch ansprechende Benutzeroberfläche ermöglicht. Sowohl der Funktionsumfang von streamon als auch das Angebot an Streaming-Inhalten wird von den beteiligten Entwicklern stetig weiterentwickelt bzw. um neue Webseiten erweitert. Diese werden auch als Site-Plugins bezeichnet, welche auf die eigentlichen Quellen verweisen die für das bereitgestellte Angebot verantworlich sind! 
***



### | [GitHub](https://github.com/xstreamon/plugin.video.streamon/) |

