# plugin.video.osmosix
Kodi add-on to add streams to library

This Version is only for use with a MySQL-Database-Server.
It will not work with the Kodi SQL-Video-Database.

For use with this Version you need a 
"advancedsettings.xml"

<videolibrary>
  <importwatchedstate>true</importwatchedstate>
  <importresumepoint>true</importresumepoint>
</videolibrary>

Info´s here:
http://kodi.wiki/view/advancedsettings.xml

Forum:
https://www.kodinerds.net/index.php/Thread/53307-Beta-osmosix-Streams-zur-DB-hinzuf%C3%BCgen/
